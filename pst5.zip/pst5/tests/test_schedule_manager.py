# tests/test_schedule_manager.py
import pytest
import os
from app.schedule import ScheduleManager

# A pytest fixture creates a clean environment for each test function.
@pytest.fixture
def fresh_manager():
    """Creates a fresh ScheduleManager instance using a temporary test data file."""
    test_file = "test_data.json"
    # ARRANGE: Ensure no old test file exists.
    if os.path.exists(test_file):
        os.remove(test_file)
    return ScheduleManager(data_path=test_file)

def test_create_course(fresh_manager):
    # ARRANGE: We have a fresh manager from the fixture.
    # ACT: Call the method we want to test.
    fresh_manager.create_course("Beginner Piano", "Piano", 1)
    # ASSERT: Check if the outcome is what we expect.
    assert len(fresh_manager.courses) == 1
    assert fresh_manager.courses[0].name == "Beginner Piano"

def test_record_payment_and_history(fresh_manager):
    # ARRANGE: Add a dummy student to the manager for the test.
    # This test verifies the core financial logic you added in Fragment 5.1.
    # fresh_manager.students.append(...)
    stu, _msg = fresh_manager.register_new_student("Unit Test", "Piano", [])
    student_id_to_test = stu.user_id

    # ACT: Record a payment for that student.
    fresh_manager.record_payment(student_id_to_test, 100.00, "Credit Card")
    
    # ACT 2: Get the payment history.
    history = fresh_manager.get_payment_history(student_id_to_test)

    # ASSERT: Check the results.
    assert isinstance(history, list)
    assert len(history) == 1
    assert history[0]['amount'] == 100.00
    assert history[0]['method'] == "Credit Card"
    assert "timestamp" in history[0]

def test_get_payment_history_no_results(fresh_manager):
    # Implement a test that checks if get_payment_history
    student_id_to_test = 123  
    history = fresh_manager.get_payment_history(student_id_to_test)
    assert isinstance(history, list)
    assert history == []
    
    # returns an empty list for a student with no payments.

# tests/test_schedule_manager.py
# ... (fixture setup) ...
